package com.example.servervagasrest.controller.dto;

public record LoginRequest(String username, String password) {}