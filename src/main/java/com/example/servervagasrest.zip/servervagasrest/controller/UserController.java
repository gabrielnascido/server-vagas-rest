package com.example.servervagasrest.controller;

public class UserController {
}
