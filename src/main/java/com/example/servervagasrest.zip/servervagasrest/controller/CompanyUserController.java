package com.example.servervagasrest.controller;

import com.example.servervagasrest.controller.dto.CompanyUserResponseDTO;
import com.example.servervagasrest.controller.dto.CompanyUserUpdateDTO;
import com.example.servervagasrest.exception.ForbiddenAccessException;
import com.example.servervagasrest.model.CompanyUser;
import com.example.servervagasrest.model.User;
import com.example.servervagasrest.service.CompanyUserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/companies")
public class CompanyUserController {

    private final CompanyUserService companyUserService;

    public CompanyUserController(CompanyUserService companyUserService) {
        this.companyUserService = companyUserService;
    }

    @PostMapping
    public ResponseEntity<Map<String, String>> create(@Valid @RequestBody CompanyUser user) {

        companyUserService.create(user);

        Map<String, String> response = Map.of("message", "Created");

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{company_id}")
    public ResponseEntity<CompanyUserResponseDTO> findById(
            @PathVariable("company_id") Long companyId,
            @AuthenticationPrincipal User authenticatedUser) {

        CompanyUser user = companyUserService.findById(companyId);

        if (!authenticatedUser.getId().equals(companyId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        return ResponseEntity.ok(CompanyUserResponseDTO.fromEntity(user));
    }

    @PatchMapping("/{company_id}")
    public ResponseEntity<Void> update(
            @PathVariable("company_id") Long companyId,
            @Valid @RequestBody CompanyUserUpdateDTO updateData,
            @AuthenticationPrincipal User authenticatedUser){

        CompanyUser user = companyUserService.findById(companyId);

        if (!authenticatedUser.getId().equals(companyId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        if (updateData.username() != null && !updateData.username().equals(user.getUsername())) {
            throw new com.example.servervagasrest.service.exception.ImmutableFieldException("O username não pode ser alterado");
        }

        companyUserService.update(user, updateData);

        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{company_id}")
    public ResponseEntity<Map<String, String>> delete(
            @PathVariable("company_id") Long companyId,
            @AuthenticationPrincipal User authenticatedUser){

        CompanyUser user = companyUserService.findById(companyId);

        if (!authenticatedUser.getId().equals(companyId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        companyUserService.delete(user);

        Map<String, String> response = Map.of("message", "Company deleted successfully");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
