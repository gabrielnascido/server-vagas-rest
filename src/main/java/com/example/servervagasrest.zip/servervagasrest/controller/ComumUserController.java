package com.example.servervagasrest.controller;

import com.example.servervagasrest.controller.dto.ComumUserResponseDTO;
import com.example.servervagasrest.controller.dto.ComumUserUpdateDTO;
import com.example.servervagasrest.exception.ForbiddenAccessException;
import com.example.servervagasrest.model.ComumUser;
import com.example.servervagasrest.model.User;
import com.example.servervagasrest.service.ComumUserService;
import com.example.servervagasrest.service.TokenService;
import com.example.servervagasrest.service.exception.ImmutableFieldException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/users")
public class ComumUserController {

    private final ComumUserService comumUserService;

    public ComumUserController(ComumUserService comumUserService, TokenService tokenService) {
        this.comumUserService = comumUserService;
    }

    @PostMapping
    public ResponseEntity<Map<String, String>> create(@Valid @RequestBody ComumUser user) {

        comumUserService.create(user);

        Map<String, String> response = Map.of("message", "Created");

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{user_id}")
    public ResponseEntity<ComumUserResponseDTO> findById(
            @PathVariable("user_id") Long userId,
            @AuthenticationPrincipal User authenticatedUser) {

        ComumUser user = comumUserService.findById(userId);

        if (!authenticatedUser.getId().equals(userId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        return ResponseEntity.ok(ComumUserResponseDTO.fromEntity(user));
    }

    @PatchMapping("/{user_id}")
    public ResponseEntity<Void> update(
            @PathVariable("user_id") Long userId,
            @Valid @RequestBody ComumUserUpdateDTO updateData,
            @AuthenticationPrincipal User authenticatedUser){

        ComumUser user = comumUserService.findById(userId);

        if (!authenticatedUser.getId().equals(userId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        if (updateData.username() != null && !updateData.username().equals(user.getUsername())) {
            throw new ImmutableFieldException("O username não pode ser alterado");
        }

        comumUserService.update(user, updateData);

        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{user_id}")
    public ResponseEntity<Map<String, String>> delete(
            @PathVariable("user_id") Long userId,
            @AuthenticationPrincipal User authenticatedUser){

        ComumUser user = comumUserService.findById(userId);

        if (!authenticatedUser.getId().equals(userId)) {
            throw new ForbiddenAccessException("Forbidden");
        }

        comumUserService.delete(user);

        Map<String, String> response = Map.of("message", "User deleted successfully");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
