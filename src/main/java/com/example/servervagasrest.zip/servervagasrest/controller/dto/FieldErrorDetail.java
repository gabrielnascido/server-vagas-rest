package com.example.servervagasrest.controller.dto;

public record FieldErrorDetail(String field, String error) {}