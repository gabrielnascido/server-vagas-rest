package com.example.servervagasrest.service;

import com.example.servervagasrest.model.Job;
import com.example.servervagasrest.repository.JobsRepository;
import org.springframework.stereotype.Service;

@Service
public class JobsService {
    private final JobsRepository jobsRepository;

    public JobsService(JobsRepository jobsRepository) { this.jobsRepository = jobsRepository; }

    public Job create(Job job) {
        return jobsRepository.save(job);
    }

}
